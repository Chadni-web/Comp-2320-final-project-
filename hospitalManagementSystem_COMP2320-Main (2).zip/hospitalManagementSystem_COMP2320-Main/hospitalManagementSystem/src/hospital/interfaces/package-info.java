/**
 * 
 */
/**
 * 
 */
package hospital.interfaces;