package hospital.exceptions;

public class InvalidRoomNumberException extends Exception {
    public InvalidRoomNumberException(String message) {
        super(message);
    }
}