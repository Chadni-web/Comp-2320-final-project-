package hospital.exceptions;

public class InvalidCapacityException extends Exception {
	public InvalidCapacityException(String message) {
		super(message);
	}
}
